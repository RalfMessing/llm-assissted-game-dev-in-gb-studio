# ServiceEngineering_Form2 – Grundspiel (GB Studio 4.3.2)

Top-Down-Adventure mit Titelbildschirm, Wald- und Dorfszene, Spielfigur mit Laufanimationen,
Wandkollision, Szenenübergängen und Interaktionen (A-Knopf + Trigger).

## Was ist enthalten?

| Bereich | Datei(en) | Funktion |
|---|---|---|
| Titelbildschirm | `project/scenes/title_screen/scene.gbsres` | Startszene, ruft Script „Title Menu“ auf |
| Waldszene | `project/scenes/forest/…` | 20×18 Tiles, Bäume mit Kollision, Wegweiser, Ausgang rechts |
| Dorfszene | `project/scenes/village/…` | 3 Häuser, Zaun, Dorfältester, Ausgang links |
| Script: Title Menu | `project/scripts/game/title_menu.gbsres` | Spieler ausblenden, Menü „Start Game“ / „Steuerung“ |
| Script: Start New Game | `project/scripts/game/start_new_game.gbsres` | Variablen zurücksetzen, Wechsel in den Wald |
| Script: Warp To Village | `project/scripts/world/warp_to_village.gbsres` | Übergang Wald → Dorf, setzt `VisitedVillage` |
| Script: Warp To Forest | `project/scripts/world/warp_to_forest.gbsres` | Übergang Dorf → Wald |
| Script: Read Forest Sign | `project/scripts/interaction/read_forest_sign.gbsres` | Schild lesen (A-Knopf), setzt `ReadForestSign` |
| Script: Talk Elder | `project/scripts/interaction/talk_elder.gbsres` | NPC-Dialog mit Emote, setzt `MetElder` (Actor-Parameter „Elder“) |
| Script: Open Treasure Chest | `project/scripts/interaction/open_treasure_chest.gbsres` | **A1** Truhe einmalig öffnen (Actor-Parameter „Chest“) |
| Script: Treasure Chest Init | `project/scripts/interaction/treasure_chest_init.gbsres` | **A1** Truhen-Aussehen beim Szenenstart aus `ChestOpened` herstellen |
| Truhe (Actor) | `project/scenes/forest/actors/treasure_chest.gbsres` | **A1** Truhe im Wald bei Tile (11, 12) |
| Script: Talk Guard | `project/scripts/interaction/talk_guard.gbsres` | **A2** Wächter-Dialog „Willkommen in unserem Dorf.“, beliebig oft |
| Wächter (Actor) | `project/scenes/village/actors/guard.gbsres` | **A2** Wächter im Dorf bei Tile (2, 11), neben dem Eingang |
| Script: Collect Coin | `project/scripts/coins/collect_coin.gbsres` | **A3** Münze einsammeln (Parameter: Actor „Coin“, Variable „Taken“) |
| Script: Coin Init | `project/scripts/coins/coin_init.gbsres` | **A3** Eingesammelte Münzen beim Szenenstart entfernen |
| Script: Show Coin Counter | `project/scripts/debug/show_coin_counter.gbsres` | **A3** Debug-Ausgabe „Münzen: X“ (Select-Taste) |
| Münzen (Actors) | `project/scenes/forest/actors/coin_1…3.gbsres` | **A3** 3 Münzen im Wald bei (3, 6), (16, 13), (6, 14) |
| Hausszene | `project/scenes/house/…` | **A4** Neues Hausinneres 20×18 Tiles, Wände/Tisch/Bett massiv, Fußmatte = Ausgang |
| Script: Warp To House | `project/scripts/world/warp_to_house.gbsres` | **A4** Übergang Dorf → Haus, Ankunft (9, 15), Blick nach oben |
| Script: Warp House To Village | `project/scripts/world/warp_house_to_village.gbsres` | **A4** Übergang Haus → Dorf, Ankunft (4, 7), Blick nach unten |
| Trigger „To House“ | `project/scenes/village/triggers/to_house.gbsres` | **A4** Tür von Haus 1 im Dorf, Tiles (4–5, 5) |
| Trigger „Exit House“ | `project/scenes/house/triggers/exit_house.gbsres` | **A4** Fußmatte im Haus, Tiles (9–10, 17) |
| Script: Open Inventory | `project/scripts/inventory/open_inventory.gbsres` | **A6** Inventar (B-Knopf): Spiel anhalten, Icons + Bestände anzeigen, mit B schließen |
| Script: Collect Item | `project/scripts/items/collect_item.gbsres` | **A6** Gegenstand einsammeln (Parameter: Actor „Item“, Variablen „Taken“, „Count“) |
| Pilze (Actors) | `project/scenes/forest/actors/mushroom_1.gbsres`, `project/scenes/village/actors/mushroom_2.gbsres` | **A6** Pilz 1 im Wald (3, 11), Pilz 2 im Dorf (5, 15) |
| Apfel (Actor) | `project/scenes/house/actors/apple.gbsres` | **A6** Apfel im Hausinneren (12, 12) |
| Kristall (Actor) | `project/scenes/workshop/actors/gem.gbsres` | **A6** Kristall in der Werkstatt (16, 10) |
| Sprites A6 | `assets/sprites/mushroom.png`, `apple.png`, `gem.png` (+ `.gbsres`) | **A6** Weltgrafik der neuen Gegenstände |
| Inventar-Icons | `assets/fonts/gbs-mono.png` | **A6** 5 Icons (8×8) in bisher leeren Zeichenfeldern der Standardschrift: U+0081 Münze, U+008D Schlüssel, U+008F Pilz, U+0090 Apfel, U+009D Kristall |
| Script: Enemy AI | `project/scripts/enemy/enemy_ai.gbsres` | **A7** Gegner-KI: Patrouille 2 rechts / 2 links, Verfolgung bei Chebyshev-Distanz ≤ 2 (Parameter: Actor „Enemy“, StartX, StartY) |
| Script: Enemy Catch Player | `project/scripts/enemy/enemy_catch_player.gbsres` | **A7** Kontakt: Nachricht, dann zurück ins Startmenü |
| Schleim (Actor) | `project/scenes/forest/actors/slime.gbsres` | **A7** Gegner im Wald, Patrouillenstart (8, 14), Tempo 0,5 |
| Sprite A7 | `assets/sprites/slime.png` (+ `.gbsres`) | **A7** Schleim, 2 Frames (wabert) |
| Variablen | `project/variables.gbsres` | `MetElder` (0), `ReadForestSign` (1), `VisitedVillage` (2), `TitleChoice` (3), `ChestOpened` (4), `CoinCount` (5), `Coin1Taken`–`Coin3Taken` (6–8), `SwitchOn` (9), `KeyTaken` (10), **A6:** `MushroomCount` (11), `Mushroom1Taken`/`Mushroom2Taken` (12/13), `AppleCount` (14), `AppleTaken` (15), `GemCount` (16), `GemTaken` (17), **A7:** `EnemyX` … `EnemyStepY` (18–35) |
| Einstellungen | `project/settings.gbsres` | Startszene = Titelbildschirm, Spieler-Sprite = `hero` |
| Hintergründe | `assets/backgrounds/title_screen.png`, `forest.png`, `village.png`, `house.png` (A4) | je 160×144 px |
| Sprites | `assets/sprites/hero.png` (Spieler, 6 Frames), `elder.png` (NPC), `sign.png` (Schild), `chest.png` (Truhe: Zustand "" = zu, Zustand "Open" = offen, je 1 Frame), `coin.png` (Münze, 1 Frame) | |
| Basis-Tiles | `assets/tilesets/basic_tiles.png` | Gras, Blume, Weg, Baum, Zaun, Dach, Wand, Fenster, Tür |
| Generator | `tools/generate_project.py` | Erzeugt alle obigen Dateien neu (Python 3 + Pillow) |

Die Wandkollisionen sind direkt in den Szenendateien (`"collisions"`) hinterlegt: alle Baum-, Haus- und Zaun-Tiles sind massiv.

## Steuerung im Spiel

| Taste (Tastatur) | Game-Boy-Knopf | Funktion |
|---|---|---|
| Pfeiltasten ↑ ↓ ← → | Steuerkreuz | laufen (**nur** Pfeiltasten, WASD ist abgeschaltet) |
| **A** | A | sprechen / lesen / öffnen / Schalter (vor dem Objekt stehen und hinschauen), Textboxen weiter |
| **B** | B | Inventar öffnen / schließen (A6) |
| Enter | Start | – |
| Shift | Select | Münzzähler (Debug) |

Rand der Karte (Weg) = Gebiet wechseln. Die Belegung steht in `project/settings.gbsres` (`customControls…`);
in GB Studio: *Einstellungen → Steuerung*.

## Hinweise

- Texte im Spiel verwenden meist „ae/oe/ue“. Ausnahme ab A3: „Münze gefunden!“, „Münzen: X“ und „Münzzähler“ (vorgegebener Text; die Standardschrift enthält ü/ä).
- Eigene Änderungen an Karten/Dialogen lassen sich in `tools/generate_project.py` vornehmen und mit
  `python tools/generate_project.py` neu erzeugen (GB Studio vorher schließen). IDs bleiben dabei stabil.

## A1 – Interaktive Schatztruhe

| Kriterium | Umsetzung |
|---|---|
| A1.1 Position, geschlossen, solide | Actor `Treasure Chest` bei (11, 12), Standard-Zustand = geschlossen, Animationsgeschwindigkeit „None“ (255); Actor-Kollision + 2×2 massive Kollisions-Tiles in `forest/scene.gbsres` |
| A1.2 Nur direkt davor + Blickrichtung | Eingebaute A-Knopf-Interaktion von GB Studio (prüft das Feld direkt vor dem Spieler) |
| A1.3 Sofortiger Sprite-Wechsel, Nachricht, Spieler steht | `EVENT_ACTOR_SET_STATE` („Open“) vor `EVENT_TEXT`; Interaktions-Scripts sperren die Spielerbewegung, bis das Script endet |
| A1.4 Kein Doppel-Öffnen | `ChestOpened` wird als **erste** Aktion gesetzt |
| A1.5 Erneute Interaktion wirkungslos | `If ChestOpened` → leerer Zweig |
| A1.6 Dauerhaft offen | Actor-„On Init“ ruft `Treasure Chest Init` auf; `Start New Game` setzt `ChestOpened` zurück |

**Fix v2:** Die Truhe nutzt jetzt zwei Animations-Zustände mit je einem Frame statt zwei Frames in einer Animation. Vorher hat GB Studio die beiden Frames automatisch abgespielt, und die Truhe wechselte im Sekundentakt zwischen offen und zu.

## A2 – NPC Wächter mit Dialog

Der Wächter steht in der Dorfszene direkt unterhalb des Wegs, ein Feld rechts neben dem linken Dorfeingang
(Trigger „To Forest“ bei x = 0, y = 8–9). Er belegt die Tiles (2–3, 10–11) und blickt nach unten.

| Kriterium | Umsetzung |
|---|---|
| A2.1 Neben dem Eingang, versperrt ihn nicht | Actor `Guard` bei (2, 11) → belegt (2–3, 10–11). Eingang (0–1, 8–9), Weg und Spawnpunkt (2, 9) bleiben frei; der Generator prüft das per Selbsttest |
| A2.2 Feste Blickrichtung, keine Bewegung | Sprite `guard` vom Typ „fixed“ mit genau einem Frame (zeigt immer dasselbe Bild), Richtung `down`, Animationsgeschwindigkeit „None“ (255), kein On-Init-/On-Update-Script, keine Bewegungs-Events |
| A2.3 Von allen vier Seiten solide | Actor-Kollision (keine Kollisionsgruppe) + 2×2 massive Kollisions-Tiles in `village/scene.gbsres` |
| A2.4 Nur bei ≤ 1 Feld Abstand + Blickrichtung | Eingebaute A-Knopf-Interaktion („On Interact“) von GB Studio: prüft nur das Feld direkt vor dem Spieler. Kein Trigger → bloße Annäherung startet nichts |
| A2.5 Exakter Text, Spieler gesperrt | `EVENT_TEXT` mit „Willkommen in / unserem Dorf.“ (nur Zeilenumbruch für die Box). Die Textbox ist modal; Interaktions-Scripts sperren die Spielerbewegung bis zum Script-Ende |
| A2.6 Beliebig oft, identisch | Script ohne Variablen, ohne Bedingungen, ohne Zustandsänderung |
| A2.7 Dreht sich nie zum Spieler | Kein „Actor Face Towards“-Event; zusätzlich zeigt das „fixed“-Sprite unabhängig von der internen Richtung immer dasselbe Bild |

**Testwege im Spiel:** von hinten = auf dem Weg über ihm stehen und nach unten schauen; von der Seite = rechts neben ihm (x = 4) nach links schauen; von vorn = unter ihm (y = 12, oberhalb des Zauns) nach oben schauen. In allen drei Fällen erscheint derselbe Text und der Wächter bleibt unverändert.

## A3 – Sammelobjekt (Münze) mit Zähler

Jede Münze ist ein Actor mit **Kollisionsgruppe 1**. Dadurch ist sein Haupt-Script in GB Studio
nicht „On Interact“ (A-Knopf), sondern **„On Hit: Player“**: Es startet, sobald der Spieler die Münze berührt
(hineinläuft oder überlappt), aus jeder Richtung.

| Kriterium | Umsetzung |
|---|---|
| A3.1 ≥ 3 feste Positionen | `Coin 1` (3, 6), `Coin 2` (16, 13), `Coin 3` (6, 14) im Wald; der Generator prüft: frei, nicht auf Actor/Ausgang, vom Spawn aus erreichbar |
| A3.2 Variable mit Startwert 0, prüfbar | `CoinCount` (Variable 5). Startwert 0 beim Einschalten, „Start New Game“ setzt sie zusätzlich auf 0. **Debug:** Select-Taste im Wald/Dorf → Textbox „Münzen: X“. Alternativ im GB-Studio-Debugger (Variable `CoinCount`) |
| A3.3 Sofort weg, +1 | `Collect Coin`: `Taken = 1` → `Actor Deactivate` (Münze ist im selben Frame weg) → `Increment CoinCount` |
| A3.4 Nur einmal | Erste Aktion ist `If Taken` → dann nichts. Deaktivierte Actors kollidieren nicht mehr; die Engine hat zusätzlich Treffer-Schutzframes |
| A3.5 Nach Szenenwechsel weg, Zähler bleibt | Pro Münze eine globale Variable `Coin1Taken`–`Coin3Taken` (6–8); „On Init“ jeder Münze ruft `Coin Init` auf und deaktiviert eingesammelte Münzen. `CoinCount` ist global |

### A3 – Regression (Truhe aus A1)

| Kriterium | Umsetzung |
|---|---|
| A3R.1 Derselbe Zähler | `Open Treasure Chest` enthält `Increment CoinCount` (Variable 5), keine zweite Variable |
| A3R.2 Text | „Münze gefunden!“ ersetzt „Die Truhe wurde geoeffnet!“ |
| A3R.3 A1 unverändert | Reihenfolge `If ChestOpened` → `ChestOpened = 1` → Zustand „Open“ → (+1) → Text. Kollision, Position, Init-Script unverändert. Die +1 liegt im „false“-Zweig, also nur beim ersten Öffnen |

**Test:** Neues Spiel → Select (zeigt 0) → drei Münzen einsammeln (Select zeigt 3) → Truhe öffnen
(„Münze gefunden!“, Select zeigt 4) → erneut öffnen (kein Text, bleibt 4) → ins Dorf und zurück
(Münzen bleiben weg, Select zeigt 4).

## A4 – Tür zu neuer Szene (Dorf ↔ Hausinneres)

Haus 1 im Dorf (links oben) hat jetzt eine **begehbare Doppeltür** (Tiles 4–5, 5). Sie ist doppelt breit, weil der
Spieler 16 px = 2 Tiles breit ist und durch eine 1 Tile breite Tür nicht hindurchpasst. Ein Trigger liegt genau auf diesen
beiden Tür-Tiles und lädt die neue Szene **House**. Dort führt die **Fußmatte** im unteren Türausschnitt (Tiles 9–10, 17)
zurück ins Dorf.

| Kriterium | Umsetzung |
|---|---|
| A4.1 Neue Szene, begehbar, Wandkollision | `project/scenes/house/scene.gbsres`, Hintergrund `house.png`. Rahmen, Rückwand (3 Reihen), Tisch (5–6, 9–10) und Bett (15–16, 4–6) sind massiv. Der Generator prüft per Breitensuche, dass der Raum begehbar ist |
| A4.2 Nur bei Berührung | Trigger 2×1 exakt auf dem Tür-Tile bzw. der Fußmatte. Das Feld davor löst nichts aus (Bounding Box des Spielers = untere 16×8 px). Die Tür ist nur frontal von unten betretbar, da links/rechts davon Wand ist |
| A4.3 Feste Ankunft im Haus | `Warp To House` → (9, 15), Blick nach oben: freier Boden, eine Reihe Abstand zur Fußmatte (y = 17) |
| A4.4 Rückweg | `Warp House To Village` → (4, 7), Blick nach unten: Weg vor dem Haus, eine Reihe Abstand zur Tür (y = 5) |
| A4.5 Keine Schleife | Beide Ankunftsfelder liegen **außerhalb** jedes Triggers. Ein Trigger feuert erst, wenn der Spieler ein Feld betritt, also nie direkt nach dem Laden |
| A4.6 Sofort steuerbar | Die Übergangs-Scripts bestehen nur aus „Switch Scene“, ohne Lock oder Textbox. Das neue Szenen-„On Init“ setzt nur die Select-Taste (Münzzähler) |

**Test (5×):** Im Dorf auf dem Weg nach oben zur linken Haustür → Haus lädt, Spieler steht über der Matte →
2× nach unten → Dorf lädt, Spieler steht vor der Tür → 2× nach oben → wieder im Haus … Kein Hin-und-Her-Springen,
nach jedem Wechsel sofort laufen.

## A6 – Einfaches Inventarsystem

**Idee:** Das Inventar ist eine bildschirmfüllende, *modale* Textbox. Modale Textboxen + `Script Lock` halten in
GB Studio das ganze Spiel an (Spieler, Actors, Timer, Knopf-Scripts). Die Icons sind 8×8-Zeichen der Standardschrift
„GBS Mono“ (in bisher leeren Feldern), die Anzahlen werden mit `$NN$` direkt aus den Spielvariablen gedruckt.
Da die Schrift monospace ist, stehen Icon, Name und Anzahl exakt in Spalten.

| Kriterium | Umsetzung |
|---|---|
| A6.1 ≥ 3 Typen, feste Positionen, ein Typ ≥ 2 | Neue Typen **Pilz** (2×: Wald (3, 11), Dorf (5, 15)), **Apfel** (Haus (12, 12)), **Kristall** (Werkstatt (16, 10)); dazu Münzen (3× + Truhe) und Schlüssel (A6R). Der Generator prüft: freies Feld, erreichbar, nicht auf Actor/Trigger/Spawn |
| A6.2 Verschwinden, +1 genau dieses Typs, Start 0 | `Collect Item` (On Hit: Player): `Taken = 1` → `Actor Deactivate` → `Count + 1`. Je Typ eine eigene Count-Variable. `Start New Game` setzt 11–17 auf 0 |
| A6.3 Öffnen/Schließen mit B | Jede Spielszene (Wald, Dorf, Haus, Werkstatt) setzt im „On Init“ `Attach Script To Button: B` → `Open Inventory`. Die Textbox schließt **nur** mit B (`closeButton: b`) |
| A6.4 Icon + Anzahl je Typ | Eine Zeile pro Typ: Icon-Zeichen + `x$NN$` (Reihenfolge: Münzen, Schlüssel, Pilze, Äpfel, Kristalle). Einrückung über `textX = 4` |
| A6.5 Spiel steht still | `Script Lock` + modale Textbox; Sprites werden ausgeblendet (Hide/Show Sprites). Danach `Show Sprites` + `Script Unlock` → alles läuft unverändert weiter (kein Szenenwechsel, kein Neuladen) |
| A6.6 Nicht während Dialog | Jeder Dialog (Textbox) ist modal und sperrt das Spiel; gesperrt verarbeitet GB Studio keine Knopf-Scripts → B startet das Inventar dort nicht. B schließt außerdem keine Dialoge (die schließen mit A) |
| A6.7 Bestände bleiben | Alle Bestände sind globale Variablen; bereits eingesammelte Gegenstände werden per „On Init“ (`Coin Init`) beim Szenenstart entfernt |

### A6 – Regression

| Kriterium | Umsetzung |
|---|---|
| A6R.1 Münzen + Schlüssel im Inventar | Zeilen „Münzen x`$05$`“ (CoinCount) und „Schlüssel x`$10$`“ (KeyTaken, 0/1) |
| A6R.2 Eine Datenquelle | Das Inventar hat **keine eigenen Variablen**: es liest `CoinCount` und `KeyTaken` direkt. Die Select-Debug-Anzeige liest dieselben Variablen |
| A6R.3 Verhalten unverändert | `Collect Coin`, `Coin Init`, `Collect Key`, `Open Treasure Chest`, `Door Init`, Schalter-Scripts und alle bestehenden Actors sind **unverändert** (byte-identisch) |

**Fix v2 (A6.4 / A6R.1):** GB Studio zeichnet den Text einer Box in einen Puffer von nur **52 Kacheln**
(jedes Zeichen der Monospace-Schrift = 1 Kachel, auch Leerzeichen; Zeilenumbrüche sind gratis). Die erste Fassung
mit Namen und Leerzeichen-Spalten (~170 Zeichen) lief über: der Puffer fing von vorn an und überschrieb die oberen Zeilen –
dadurch fehlten Münzen- und Schlüsselzeile und der Text war zerstückelt. Jetzt zeigt jede Zeile nur noch **Icon + Anzahl**,
eingerückt per `textX` (kostet keine Kacheln): 40 Kacheln, selbst bei dreistelligen Werten höchstens 50.
Der Generator prüft dieses Budget per Selbsttest.

**Test:** Neues Spiel → B (alle 0) → B (zu) → Pilz im Wald + 1 Münze einsammeln → B (Münzen 1, Pilze 1) →
Schild lesen und während des Textes B drücken (kein Inventar) → Schlüssel holen, Truhe öffnen → ins Dorf, Pilz 2 →
B (Münzen 2, Schlüssel 1, Pilze 2) → Haus: Apfel, Schalter + Werkstatt: Kristall → zurück in den Wald → B (alle Werte erhalten).

## A7 – Gegner mit Verfolgungsverhalten

Im Wald patrouilliert ein **Schleim** (Actor `Slime`) unterhalb der Truhe. Seine Logik steckt komplett im Custom Script
`Enemy AI`, das als **„On Update“** des Actors läuft. Der Update-Thread startet bei jedem Szenenstart neu; das Script setzt
deshalb zuerst Position und Zustand zurück und läuft dann in einer Endlosschleife – **ein Schleifendurchlauf = höchstens ein Schritt (1 Tile)**.

| Kriterium | Umsetzung |
|---|---|
| A7.1 Feste Route 1×3 | Patrouillenstart (8, 14): 2 Schritte nach rechts → (10, 14), 2 Schritte nach links → (8, 14), usw. Zähler `EnemyPatrolSteps`, Richtung `EnemyPatrolDir` (+1/−1) – rein deterministisch |
| A7.2 Start am Patrouillenstart | `Enemy AI` beginnt mit `Actor Set Position` (StartX/StartY = 8/14) und setzt `EnemyChasing`, `EnemyPatrolDir`, `EnemyPatrolSteps`, `EnemyBlocked` zurück. Da es im Update-Thread läuft, gibt es kein Reihenfolge-Problem mit „On Init“ |
| A7.3 Verfolgung bei Distanz ≤ 2 | Vor jedem Schritt: Positionen beider Figuren in Tiles lesen, `EnemyDist = max(abs(dx), abs(dy))`. Bei ≤ 2: ein Schritt Richtung Spieler (zuerst die Achse mit dem größeren Abstand, bei Gleichstand vertikal; ist sie blockiert, die andere Achse; sonst seitlich ausweichen) |
| A7.4 Verfolgung endet sofort | Bei Distanz > 2 wird im **selben** Durchlauf (also nach spätestens einem laufenden Schritt) `EnemyChasing = 0`, Richtung = rechts, Zähler = 0 gesetzt → das aktuelle Feld ist das neue Ausgangsfeld, und er patrouilliert dort sofort weiter |
| A7.5 Keine Wände, kein Hängen, Szene bleibt | Jeder Schritt ist `Actor Move Relative` mit Kollision **„Wände“**. Felder außerhalb der Karte zählen in der Engine als massiv → er kann die Szene nicht verlassen. Ist ein Schritt blockiert (Position unverändert), dreht er um; sind links **und** rechts blockiert, weicht er 1 Feld nach unten/oben aus. Das Schild hat jetzt massive Kollisions-Tiles (wie Truhe und Wächter) |
| A7.6 Langsamer als der Spieler | Gegner-Tempo 0,5 px/Frame, Spieler 1 px/Frame |
| A7.7 Kontakt → Startmenü | Kollisionsgruppe 1 → das Actor-Script ist „On Hit: Player“ (feuert, sobald sich die Felder überlappen oder der Spieler in ihn hineinläuft) → `Enemy Catch Player`: Script Lock, Nachricht „Der Schleim hat dich erwischt!“, Gegner deaktivieren, Wechsel zum Titelbildschirm. Dort muss „Start Game“ gewählt werden, das den Spielstand zurücksetzt |

Hinweis: Die Kollision „Actors“ wird bewusst **nicht** genutzt – sie zählt in GB Studio auch den Spieler als Hindernis, der Gegner
bliebe dann immer ein Feld vor ihm stehen und es käme nie zum Kontakt. Feste Objekte im Wald sind deshalb über Kollisions-Tiles massiv.
Inventar (B), Select-Anzeige und Dialoge halten den Gegner an (Script Lock / modale Textbox).

**Test:** Neues Spiel → Weg nach rechts gehen (Gegner ist ≥ 5 Reihen entfernt, keine Reaktion) → beobachten: Schleim läuft (8,14) ↔ (10,14) →
nach unten Richtung Truhe gehen, bis ≤ 2 Felder Abstand → Schleim folgt → nach oben auf den Weg flüchten → Schleim bleibt stehen, wo er ist, und
patrouilliert von dort weiter → erneut nähern und berühren lassen → Nachricht → Titelbildschirm → „Start Game“ (alles zurückgesetzt).
Szene verlassen und wieder betreten → Schleim steht wieder bei (8, 14).
